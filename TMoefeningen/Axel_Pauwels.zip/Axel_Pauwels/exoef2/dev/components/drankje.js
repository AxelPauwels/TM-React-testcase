import React from 'react';
import BartenderApi from "../apis/bartender_api";

const Drankje = (props) => {



    return (
        <div>
        </div>
    )
}

export default Drankje;
